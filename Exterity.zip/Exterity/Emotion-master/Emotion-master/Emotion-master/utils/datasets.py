from scipy.io import loadmat
import pandas as pd
import numpy as np
from random import shuffle
import os
import cv2

class DataManager(object):
    """Class for loading fer2013 emotion classification dataset or
        imdb gender classification dataset."""
    def __init__(self, dName='imdb', dPath=None, Size=(48, 48)):

        self.dName = dName
        self.dPath = dPath
        self.Size = Size
        if self.dPath != None:
            self.dPath = dPath
        elif self.dName == 'imdb':
            self.dPath = '../datasets/imdb_crop/imdb.mat'
        elif self.dName == 'fer2013':
            self.dPath = '../datasets/fer2013/fer2013.csv'
        elif self.dName == 'KDEF':
            self.dPath = '../datasets/KDEF/'
        else:
            raise Exception('Incorrect dataset name, please input imdb or fer2013')

    def get_data(self): #initialise the fer datasets for processing
        if self.dName == 'imdb':
            setData = self._load_imdb()
        elif self.dName == 'fer2013':
            setData = self._load_fer2013()
        elif self.dName == 'KDEF':
            setData = self._load_KDEF()
        return setData

    def _load_imdb(self): #load in the imdb model for analysis of the dataset
        Threshold = 3
        Dataset = loadmat(self.dPath)
        imageArray = Dataset['imdb']['full_path'][0, 0][0]
        Gender = Dataset['imdb']['gender'][0, 0][0]
        Score = Dataset['imdb']['face_score'][0, 0][0]
        Score2 = Dataset['imdb']['second_face_score'][0, 0][0]
        faceScore = Score > Threshold
        faceScore2 = np.isnan(Score2)
        unGender = np.logical_not(np.isnan(Gender))
        Cover = np.logical_and(faceScore, faceScore2)
        Cover = np.logical_and(Cover, unGender)
        imageArray = imageArray[Cover]
        Gender = Gender[Cover].tolist()
        image = []
        for imageArgument in range(imageArray.shape[0]):
            image = imageArray[imageArgument][0]
            image.append(image)
        return dict(zip(image, Gender))

    def _load_fer2013(self): #load in the fer dataset
        Info = pd.read_csv(self.dPath)
        Pixels = Info['pixels'].tolist()
        width, height = 48, 48
        Face = []
        for pixel_sequence in Pixels:
            face = [int(pixel) for pixel in pixel_sequence.split(' ')]
            face = np.asarray(face).reshape(width, height)
            face = cv2.resize(face.astype('uint8'), self.Size)
            Face.append(face.astype('float32'))
        Face = np.asarray(Face)
        Face = np.expand_dims(Face, -1)
        Emotion = pd.get_dummies(Info['emotion']).as_matrix()
        return Face, Emotion

    def _load_KDEF(self): #load in the kdef file to analyse the datasets
        classArgument = get_class_to_arg(self.dName)
        classAmount = len(classArgument)

        file_paths = []
        for folder, subfolders, filenames in os.walk(self.dPath):
            for filename in filenames:
                if filename.lower().endswith(('.jpg')):
                    file_paths.append(os.path.join(folder, filename))

        faceAmount = len(file_paths)
        y_size, x_size = self.Size
        Face = np.zeros(shape=(faceAmount, y_size, x_size))
        Emotion = np.zeros(shape=(faceAmount, classAmount))
        for file_arg, file_path in enumerate(file_paths):
            iArray = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
            iArray = cv2.resize(iArray, (y_size, x_size))
            Face[file_arg] = iArray
            file_basename = os.path.basename(file_path)
            file_emotion = file_basename[4:6]
            # there are two file names in the dataset that don't match the given classes
            try:
                eArgument = classArgument[file_emotion]
            except:
                continue
            Emotion[file_arg, eArgument] = 1
        Face = np.expand_dims(Face, -1)
        return Face, Emotion

def get_labels(dName): #get the labels for each emotion 
    if dName == 'fer2013':
        return {0:'angry',1:'disgust',2:'fear',3:'happy',
                4:'sad',5:'surprise',6:'neutral'}
    elif dName == 'imdb':
        return {0:'woman', 1:'man'}
    elif dName == 'KDEF':
        return {0:'AN', 1:'DI', 2:'AF', 3:'HA', 4:'SA', 5:'SU', 6:'NE'}
    else:
        raise Exception('Invalid dataset name')

def get_class_to_arg(dName='fer2013'): #decide on which emotion each image in the dataset is
    if dName == 'fer2013':
        return {'angry':0, 'disgust':1, 'fear':2, 'happy':3, 'sad':4,
                'surprise':5, 'neutral':6}
    elif dName == 'imdb':
        return {'woman':0, 'man':1}
    elif dName == 'KDEF':
        return {'AN':0, 'DI':1, 'AF':2, 'HA':3, 'SA':4, 'SU':5, 'NE':6}
    else:
        raise Exception('Invalid dataset name')

def split_imdb_data(setData, Valid=.2, Shuff=False): #train the model
    gTruthkeys = sorted(setData.keys())
    if Shuff == True:
        shuffle(setData)
    trainSplit = 1 - Valid
    Train = int(trainSplit * len(setData))
    Keys = gTruthkeys[:Train]
    vKeys = gTruthkeys[Train:]
    return Keys, vKeys

def split_data(x, y, Valid=.2): #split up all the trained data
    sampleAmount = len(x)
    trainSampleamount = int((1 - Valid)*sampleAmount)
    train_x = x[:trainSampleamount]
    train_y = y[:trainSampleamount]
    val_x = x[trainSampleamount:]
    val_y = y[trainSampleamount:]
    dataTrain = (train_x, train_y)
    dataValid = (val_x, val_y)
    return dataTrain, dataValid

#code has been used from the https://github.com/petercunha/Emotion emotion recognition topic, also uses the datasets provided by the website
#variable names have been changed within here to ensure understanding of the program