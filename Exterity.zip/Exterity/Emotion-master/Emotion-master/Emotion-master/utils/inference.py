import cv2
from keras.preprocessing import image

def load_image(imagePath, Gray=False, targetSize=None): #load the selected image into the program
    pImage = image.load_img(imagePath, Gray, targetSize)
    return image.img_to_array(pImage)

def load_detection_model(model): #initialise the detection model
    Detection = cv2.CascadeClassifier(model)
    return Detection

def detect_faces(Detection, grayArray): #detect where the faces are within the screen
    return Detection.detectMultiScale(grayArray, 1.3, 5)


def apply_offsets(faceLoc, Offsets): #apply the offsets to the image
    x, y, width, height = faceLoc
    x_off, y_off = Offsets
    return (x - x_off, x + width + x_off, y - y_off, y + height + y_off)

#based off the https://github.com/petercunha/Emotion tutorial 
#variable name have been changed to ensure understanding

