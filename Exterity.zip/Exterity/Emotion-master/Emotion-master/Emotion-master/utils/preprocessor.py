import numpy as np
from scipy.misc import imread, imresize


def preprocess_input(Coord, bool1=True): #preprocess input to ensure the image is in a desirable format
    Coord = Coord.astype('float32')
    Coord = Coord / 255.0
    if bool1:
        Coord = Coord - 0.5
        Coord = Coord * 2.0
    return Coord

def _imread(imageName): #ImRead Normalise the face to gray to ensure that background noise is minimalised 
        return imread(imageName)

def _imresize(imageArray, Length): #resizes the image to ensure that only the faces are located within the box
        return imresize(imageArray, Length)

def to_categorical(integerClasses, numClasses=2): #ensure that the data is processed 
    integerClasses = np.asarray(integerClasses, dtype='int')
    numSamples = integerClasses.shape[0]
    Direct = np.zeros((numSamples, numClasses))
    Direct[np.arange(numSamples), integerClasses] = 1
    return Direct

#based off the https://github.com/petercunha/Emotion tutorial 
#varibale names have been chnaged to ensure undersanding 