from __future__ import division
import cv2
import numpy as np
from keras.models import load_model
from utils.datasets import get_labels
from utils.inference import apply_offsets
from utils.preprocessor import preprocess_input



#initialise the models for training the computer vision AI
emotionPath = './models/emotion_model.hdf5'
Labels = get_labels('fer2013') 

# hyper-parameter used for the surrounding of the face
Offsets = (20, 40)

# load in the models to train to the computer AI
fCascade = cv2.CascadeClassifier('./models/haarcascade_frontalface_default.xml')
emotionClassifier = load_model(emotionPath)

# getting the shapes for the inference AI
emotionSize = emotionClassifier.input_shape[1:3]




#Get the image the User wishes to use
Capture = cv2.VideoCapture('C:/Users/stone/Documents/Emotion-master/Emotion-master/Emotion-master/demo/angrycenter.png') # Image Source

ret, bgr_image = Capture.read() #read the user's image in


Gray = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2GRAY) #If the image is Gray
Rgb = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2RGB) #if the image has colour

Faces = fCascade.detectMultiScale(Gray, scaleFactor=1.1, minNeighbors=5,
                                      minSize=(30, 30), flags=cv2.CASCADE_SCALE_IMAGE)

for face_coordinates in Faces:

    x1, x2, y1, y2 = apply_offsets(face_coordinates, Offsets)
    grayFace = Gray[y1:y2, x1:x2]
    try:
            grayFace = cv2.resize(grayFace, (emotionSize))
    except:
            continue

    grayFace = preprocess_input(grayFace, True) #run the preprocess file for normalising the data
    grayFace = np.expand_dims(grayFace, 0)
    grayFace = np.expand_dims(grayFace, -1)
    emotionPrediction = emotionClassifier.predict(grayFace) # Return the predictions for each emotion
    emotionProbability = np.max(emotionPrediction) # find the highest image probability
    emotionArguments = np.argmax(emotionPrediction)
    Emotion = Labels[emotionArguments] #Get the string emotion of the image the user has inputted




print(Emotion) #output the emotion
print ('{:.1%}'.format(emotionProbability)) #output the percentage of which the emotion is


#based off the https://github.com/petercunha/Emotion tutorial
#varibale names have been chnaged to ensure understanding
#further changes made will be explaimned in the report