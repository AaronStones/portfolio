from flask import Flask
from flask import request
app = Flask(__name__)
import numpy
import pandas
import ast
import json

@app.route("/", methods=['POST'])
def recommend():
    # Read in tables from CSV files
    ratings = pandas.read_csv('ratings_final.csv', names=['movie_id', 'user_id', 'rating'])
    movies = pandas.read_csv('movies_final.csv', names=['movie_id', 'title'], index_col='movie_id')

    # Define adjusted rating based on mean user ratings
    mean = ratings.groupby(['user_id'], sort=False, as_index=False).mean().rename(columns={'user_id': 'user_id', 'rating': 'mean_rating'})
    ratings = pandas.merge(ratings, mean, on='user_id', how='left', sort=False)
    ratings['adjusted_rating'] = ratings['rating'] - ratings['mean_rating']

    # Create pivoted matrix from ratings data
    pivot = pandas.DataFrame({'user_id': ratings['user_id'], 'movie_id': ratings['movie_id_x'], 'rating': ratings['adjusted_rating']})
    pivot = pivot.pivot_table(index='user_id', columns='movie_id', values='rating')

    # Ensure a column exists for each movie, even if there are no ratings for that movie in the dataset
    for i, m in enumerate(range(1, 2001)):
        try:
            pivot.insert(i, m, numpy.nan, allow_duplicates=False)
        except ValueError:
            pass

    # Treat a missing rating as an average rating for that movie
    pivot = pivot.fillna(0)

    user_ratings = ast.literal_eval(request.form['user_ratings'])
    return str(get_recommendations(user_ratings, pivot, movies))

def get_recommendations(user_ratings, pivot, movies):
    # Set up user profile
    target_user = [0] * 2000
    for key, value in user_ratings.items():
        target_user[key - 1] = value

    # Find top similar users using cosine similarity
    all_users = pivot.values
    denominator1 = numpy.sqrt(sum([numpy.square(x) for x in target_user]))
    similarity = []
    for i, user in enumerate(all_users):
        numerator = [x * y for x, y in zip(target_user, user)]
        denominator2 = numpy.sqrt(sum([numpy.square(x) for x in user]))
        costheta = sum(numerator) / (denominator1 * denominator2)
        similarity.append((pivot.index[i], costheta))
    similarity.sort(key=lambda x: x[1], reverse=True)
    top_users = similarity[0:5]
    top_users_table = pandas.DataFrame()
    for user in top_users:
        top_users_table = top_users_table.append(pivot.loc[user[0]])
    top_users_table['costheta'] = [user[1] for user in top_users]

    # Predict movies based on similar users
    denominator = top_users_table['costheta'].sum()
    recommendations = []
    for i, r in enumerate(target_user):
        if r == 0.0: # If target user has not rated movie
            total = 0
            for index, row in top_users_table.iterrows():
                if not numpy.isnan(row['costheta']):
                    total += row[i + 1] * row['costheta']
            recommendations.append((i + 1, total / denominator))
    recommendations.sort(key=lambda x: x[1], reverse=True)
    recommendations = recommendations[:12]
    recommendations = [(r[0], r[1], movies.loc[r[0]]['title']) for r in recommendations]
    return json.dumps(recommendations[:12])

if __name__ == "__main__":
    app.run(host='0.0.0.0')
