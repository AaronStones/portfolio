<?php
include("templating/setup.php");
$page = "Login";
$title = "Movie Recommender - Login"; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include("templating/head.php"); ?>
</head>
<body>
<?php include("templating/nav.php"); ?>
<!-- Start of page content -->

<div class="container my-3" role="main">
  <h1>Login</h1>
  <p>Please enter your details on this page to login to your account or <a class="link" href="register">register as a new user</a> if you do not already have an account.</p>
  <hr>
  <div id="response"></div> <!-- Response will go here -->
  <form method="post" action="../controller/login.php">

    <label for="email">Email</label>
    <input class="form-control" type="text" placeholder="Enter Email" name="email" required>

    <label for="password">Password</label>
    <input class="form-control" type="password" placeholder="Enter Password" name="password" required>

    <button type="submit" class="form-control btn btn-danger mt-3">Login</button>
  </form>
</div>

<!-- End of page content -->
<?php include("templating/footer.php"); ?>
<?php include("templating/scripts.php"); ?>
<!-- Start of AJAX script -->

<script>
alert("<?=$_POST['email']?>");
  $('form').on('submit', function(e)
  {
    e.preventDefault(); // Prevent default form behaviour so we can override it

    $('#submit').prop('disabled', true); // Disable submit button to prevent multiple submissions

    $.post('../controller/login.php', $('form').serialize(), function(data)
    {
      let response = '<div class="alert alert-' + (data.success ? 'success' : 'danger') + '">' + data.message + '</div>';
      $('#response').html(response); // Display response message

      if (data.success)
      {
        location.href = 'index'; // Success, redirect to home page
      }
      else
      {
        // Failure, enable submit button to allow resubmission
        $('#submit').prop('disabled', false);
      }
    }, 'json');
  });
</script>

<!-- End of AJAX script -->
</body>
</html>
