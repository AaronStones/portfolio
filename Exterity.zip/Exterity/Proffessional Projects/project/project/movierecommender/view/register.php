<?php
include("templating/setup.php");
$page = "Register";
$title = "Movie Recommender - Register"; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include("templating/head.php"); ?>
</head>
<body>
<?php include("templating/nav.php"); ?>
<!-- Start of page content -->

<div class="container my-3" role="main">
  <h1>Register</h1>
  <p>Please fill in this form to register a new account or <a class="link" href="login">login as an existing user</a> if you already have an account.</p>
  <hr>
  <div id="response"></div> <!-- Response will go here -->
  <form method = "post" action="../controller/register.php">
    <label for="email">Email</label>
    <input class="form-control" type="text" placeholder="Enter Email" pattern="^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$" title="Please ensure the email address is valid." name="email" required>
    <label for="password">Password</label>
    <input class="form-control" type="password" placeholder="Enter Password" pattern="^(?=.*\d)(?=.*[a-zA-Z]).{8,80}$" title="Please ensure the password is 8 characters and contains at least one letter and one number." name="password" required>
    <label for="confirm">Confirm Password</label>
    <input class="form-control" type="password" placeholder="Confirm Password" pattern="^(?=.*\d)(?=.*[a-zA-Z]).{8,80}$" title="Please ensure the password is 8 characters and contains at least one letter and one number." name="confirm" required>
    <button id="submit" type="submit" class="form-control btn btn-danger mt-3">Register</button>
  </form>
</div>

<!-- End of page content -->
<?php include("templating/footer.php"); ?>
<?php include("templating/scripts.php"); ?>
<!-- Start of AJAX script -->

<script>
  $('form').on('submit', function(e)
  {
    e.preventDefault(); // Prevent default form behaviour so we can override it

    $('#submit').prop('disabled', true); // Disable submit button to prevent multiple submissions

    $.post('../controller/register.php', $('form').serialize(), function(data)
    {
      let response = '<div class="alert alert-' + (data.success ? 'success' : 'danger') + '">' + data.message + '</div>';
      $('#response').html(response); // Display response message

      if (data.success)
      {
        // Success, redirect to allow user to login
        setTimeout(function () { location.href = 'login' }, 1000);
      }
      else
      {
        // Failure, enable submit button to allow resubmission
        $('#submit').prop('disabled', false);
      }
    }, 'json');
  });
</script>

<!-- End of AJAX script -->
</body>
</html>
