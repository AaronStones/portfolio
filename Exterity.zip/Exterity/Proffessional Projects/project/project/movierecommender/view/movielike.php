<?php
include("templating/setup.php");
$page = "Getting To Know You";
$title = "Movie Recommender - Getting To Know You"; 

if (!$loggedIn)
{
	header("Location: https://mayar.abertay.ac.uk/~cmp311gc1810/movierecommender/view/register.php");
	die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php 
include("templating/head.php"); 
include("../model/api_user.php");
include("../model/api_movie.php");
include("../model/api_tmdb.php");
?>
</head>
<body>
<?php include("templating/nav.php"); ?>
<!-- Start of page content -->

<div class="container my-3" role="main">

<?php
echo "<h1>Please Rate All of These Movies From 1 to 5</h1>";
echo "<h2>Or if you have not seen them please click the unseen button</h2><div class='row'>";
$Movie = firstMovies() ; //get first Movies Data
$Movies = json_decode($Movie) ;


for ($i=0 ; $i<sizeof($Movies) ; $i++) { //for the amount of records display a teaser for each record
?>
	<div class="col-lg-3 col-md-6 col-sm-12 col-xs-12">
	<div id="<?=$Movies[$i]->Reg_Id?>" class="card">
	<img class="card-img-top" src="<?=$Movies[$i]-> Image_Link?>" alt="Poster image" image style="width:100%" height="300" width="500">
	<div class="card-body">
	<h4 class="card-title"><?=$Movies[$i] -> Name?></h4>
	<div class="w-100 p-1 text-center">
			<i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$Movies[$i]->Reg_Id?>, 1)"> </i>
			<i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$Movies[$i]->Reg_Id?>, 2)"> </i>
			<i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$Movies[$i]->Reg_Id?>, 3)"> </i>
			<i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$Movies[$i]->Reg_Id?>, 4)"> </i>
			<i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$Movies[$i]->Reg_Id?>, 5)"> </i>
	</div>
	<button class="form-control btn btn-danger mt-3" onclick=ratingClicked(<?=$Movies[$i]->Reg_Id?>)> Have not seen </button>
	</div>
	</div>
	</div>
<?php }?>
</div>

<!-- End of page content -->
<?php include("templating/footer.php"); ?>
<?php include("templating/scripts.php"); ?>
<!-- Start of JavaScript  -->

<script>
	counter = 0;

	function ratingClicked(id, rating = -1)
	{
		document.getElementById(id).remove();
		counter += 1

		if (rating > 0) // If a value less than one is given then assume the user has not seen that movie
		{
			var post_data = { movie_id: id, rating: rating };
	
			$.ajax({
				url : 'https://mayar.abertay.ac.uk/~cmp311gc1810/movierecommender/controller/record_rating.php',
				type: "POST",
				data : post_data,
			});
		}

		if (counter >= 30)
		{
			// Done, redirect to index page
			setTimeout(function () { location.href = 'index' }, 1500);
		}
	}
</script>

<!-- End of JavaScript -->
</body>
</html>