<?php
include("templating/setup.php");
$page = "Show";
$title = "Movie Recommender - Show"; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include("templating/head.php"); ?>
</head>
<body>
<?php include("templating/nav.php"); ?>
<!-- Start of page content -->

<div class="container py-3" role="main">

    <?php /* Retrieve show details */
        include("../model/api_movie.php");
        include("../model/api_tmdb.php");

        $s = findShow($_GET["t"]); /* $s is short for show */
        $s = json_decode($s);

        if ($s->success):
    ?>
        <h1><?= $s->title ?> (<?= $s->year ?>)</h1>

        <img class="img-fluid rounded mx-auto d-block float-md-right" alt="Poster image for <?=$s->title?>" src="<?= $s->poster_path ?>">

        <h4>Overview</h4>
        <p><?= $s->overview ?></p>

        <h4>Genres</h4>
        <ul>
            <?php
                foreach($s->genres as $genre)
                {
                    echo "<li>$genre</li>";
                }
            ?>
        </ul>

        <h4>Produced By</h4>
        <ul>
            <?php
                foreach($s->produced_by as $producer)
                {
                    echo "<li>$producer</li>";
                }
            ?>
        </ul>

            <?php
                $movie_id = getMovieID($s->title);
                
                if ($loggedIn && !is_null($movie_id)):
            ?>
            <h4>Click one of the stars below to rate this movie and help us further personalise your recommendations:</h4>
            <div id='<?=$movie_id?>' class="w-100 p-1 text-center">
                <i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$movie_id?>, 1)"></i>
                <i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$movie_id?>, 2)"></i>
                <i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$movie_id?>, 3)"></i>
                <i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$movie_id?>, 4)"></i>
                <i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$movie_id?>, 5)"></i>
            </div>
        <?php endif; ?>

    <?php else: ?>

        <h1>No show found for that search term.</h1>

    <?php endif; ?>

</div>

<!-- End of page content -->
<?php include("templating/footer.php"); ?>
<?php include("templating/scripts.php"); ?>
<!-- Start of JavaScript  -->

<script>
	function ratingClicked(id, rating = -1)
	{
		document.getElementById(id).remove();
		var post_data = { movie_id: id, rating: rating };

		$.ajax({
			url : 'https://mayar.abertay.ac.uk/~cmp311gc1810/movierecommender/controller/record_rating.php',
			type: "POST",
			data : post_data,
		});
	}
</script>

<!-- End of JavaScript -->
</body>
</html>