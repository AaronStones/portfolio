<?php
	session_start(); //Begin session
	$loggedIn = isset($_SESSION['user']);
?>