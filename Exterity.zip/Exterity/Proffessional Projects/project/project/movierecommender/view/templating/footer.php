<footer class="static-bottom">
    <div class="container d-flex justify-content-around">
        <span class="footer-info">
            This product uses the TMDb API but is not endorsed or certified by TMDb
            <a href="https://www.themoviedb.org">
                <img class="footer-logo" alt="The Movie Database" src="https://www.themoviedb.org/assets/1/v4/logos/208x226-stacked-blue-e6df1ff1a41c48555a15336ae8a6b3c6f77dfae41d2a50b78e4794c1ce048792.png">
            </a>
        </span>
    </div>
</footer>