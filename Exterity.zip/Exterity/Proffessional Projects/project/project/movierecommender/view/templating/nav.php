<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
	<div class="container">
		<a class="navbar-brand" href="index">
			<img alt="Movie Recommender" src="images/logo.png">
		</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarToggle">
			<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
				<li class="nav-item <?php if ($page == "Home") echo "active"; ?>">
					<a class="nav-link" href="index">Home</a>
				</li>
				<?php if ($loggedIn): ?>
					<li class="nav-item <?php if ($page == "Account") echo "active"; ?>">
						<a class="nav-link" href="account">Account</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="../controller/logout">Logout</a>
					</li>
				<?php else: ?>
					<li class="nav-item <?php if ($page == "Register") echo "active"; ?>">
						<a class="nav-link" href="register">Register</a>
					</li>
					<li class="nav-item <?php if ($page == "Login") echo "active"; ?>">
						<a class="nav-link" href="login">Login</a>
					</li>
				<?php endif; ?>
				<li class="nav-item <?php if ($page == "Support") echo "active"; ?>">
					<a class="nav-link" href="support">Support</a>
				</li>
			</ul>

			<form class="form-inline my-2 my-lg-0" method="GET" action="../controller/search.php">
				<input class="form-control mr-sm-2" name="search" type="search" placeholder="Search" aria-label="Search">
				<button class="btn btn-outline-danger my-2 my-sm-0" type="submit">Search Movies</button>
			</form>
		</div>
	</div>
</nav>