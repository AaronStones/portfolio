<?php
include("templating/setup.php");
$page = "Home";
$title = "Movie Recommender - Home"; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include("templating/head.php"); ?>
</head>
<body>
<?php include("templating/nav.php"); ?>
<!-- Start of page content -->



<!-- End of page content -->
<?php include("templating/scripts.php"); ?>
</body>
</html>