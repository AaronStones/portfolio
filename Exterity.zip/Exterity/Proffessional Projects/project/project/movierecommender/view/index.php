<?php
include("templating/setup.php");
$page = "Home";
$title = "Movie Recommender - Home"; 

if ($loggedIn)
{
	include_once('../model/api_ratings.php');
	if (getRatingCount($_SESSION['user']->id) == 0)
	{
		header("Location: https://mayar.abertay.ac.uk/~cmp311gc1810/movierecommender/view/movielike");
		exit();
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include("templating/head.php"); ?>
</head>
<body>
<?php include("templating/nav.php"); ?>
<!-- Start of page content -->

<?php if ($loggedIn): ?>

<!-- Recommendations page (when logged in) -->
<div class="container-fluid" role="main">
	<h1>Here are some shows we think you might like...</h1>
	<p>If you have seen any of these shows, please rate them so we can find more shows that match your tastes.</p>
	<div id="recommendations" class="row justify-content-center mb-3">
		<div class="my-5">
			<h2>Please wait while we load your personalised recommendations...</h1>
			<img src="images/loader.gif" class="mx-auto d-block my-5" alt="Loading Indicator" />
		</div>
	</div>
</div>

<?php else: ?>

<!-- Landing page (when not logged in) -->
<div class="container d-flex h-100 w-100" role="main">
	<div class="row align-items-center h-100 w-100"> <!-- Call to action -->
		<div class="span6 text-center mx-auto mt-5">
			<p>Don't know what to watch? <br/> Get high quality recommendations for movies and TV shows that you'll love!</p><br/>
			<p><a class="btn btn-danger btn-lg" href="register">REGISTER AS NEW USER</a></p>
			<a class="link" href="login">Login as existing user</a>
		</div>
	</div>
</div>

<?php endif; ?>

<!-- End of page content -->
<?php include("templating/footer.php"); ?>
<?php include("templating/scripts.php"); ?>
<!-- Start of JavaScript  -->

<script>
	<?php if ($loggedIn): ?>
	$(document).ready(function()
	{
		$("#recommendations").load('https://mayar.abertay.ac.uk/~cmp311gc1810/movierecommender/controller/recommendations.php');
	});
	<?php endif; ?>

	function ratingClicked(id, rating = -1)
	{
		document.getElementById(id).remove();
		var post_data = { movie_id: id, rating: rating };

		$.ajax({
			url : 'https://mayar.abertay.ac.uk/~cmp311gc1810/movierecommender/controller/record_rating.php',
			type: "POST",
			data : post_data,
		});
	}
</script>

<!-- End of JavaScript -->
</body>
</html>