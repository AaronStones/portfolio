<?php
include("templating/setup.php");
$page = "Support";
$title = "Movie Recommender - Support"; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include("templating/head.php"); ?>
</head>
<body>
<?php include("templating/nav.php"); ?>
<!-- Start of page content -->

<div class="container my-3" role="main">
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <h2>Frequently Asked Questions</h2>

            <h6>How do you know what movies I will enjoy?</h6>
            <p class="small">
            We use a method called collaborative filtering. First we find a collection of users with similar taste to you.
            Then we look for movies you haven't seen that those similar users enjoyed.
            Finally we sort these movies based on how sure we are and send them to your <a href='index'>Home page</a>.
            </p>

            <h6>Where can I see my personalised movie recommendations?</h6>
            <p class="small">
            When you are signed in to your account, you will find your personalised recommendations on the <a href='index'>Home page</a>.
            To sign in to your account head over to the <a href='login'>Login page</a> and enter your details.
            If you don't have an account with us yet, head over to the <a href='register'>Registration page</a> to get set up with one.
            </p>

            <h6>What happens to my data when I delete my account?</h6>
            <p class="small">
            We remove all data associated with your account as soon as you request an account deletion.
            We do not keep any of your data as we believe this would infringe on your right to privacy.
            This means that we not only delete any identifying information, but also any ratings you made on your account.
            As a result of this, deleted accounts are not recoverable.
            </p>

            <h6>My question isn't answered here, what should I do?</h6>
            <p class="small">
            You can reach us through the contact form beside or below this question and a member of our team will get back to you as soon as possible.
            </p>
        </div>
        <div class="col-md-6 col-sm-12">
            <h2>Contact Us</h2>
            <form action="../controller/contact.php" method="POST">
                <label for="subject">Subject</label>
                <select class="form-control" name="subject">
                    <option value="Feedback">Feedback</option>
                    <option value="Report">Bug Report</option>
                    <option value="Complaint">Complaint</option>
                    <option value="Other">Other</option>
                </select>
                <label for="email">Email Address</label>
                <input class="form-control" type="email" name="email" required pattern="^(?=.{5,80}$)[\S]+@[\S]+\.[\S]+$">
                <label for="message">Message</label>
                <textarea class="form-control" name="message" rows="6" required pattern="^.{1,1200}$"></textarea>
                <input class="form-control btn btn-danger mt-3" type="submit" value="Submit">
            </form>
        </div>
    </div>
</div>

<!-- End of page content -->
<?php include("templating/footer.php"); ?>
<?php include("templating/scripts.php"); ?>
</body>
</html>