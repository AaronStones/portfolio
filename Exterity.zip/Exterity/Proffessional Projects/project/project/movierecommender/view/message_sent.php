<?php
include("templating/setup.php");
$page = "Message Sent";
$title = "Movie Recommender - Message Sent"; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include("templating/head.php"); ?>
</head>
<body>
<?php include("templating/nav.php"); ?>
<!-- Start of page content -->

<div class="container d-flex h-100 w-100" role="main">
	<div class="row align-items-center h-100 w-100">
		<div class="span6 text-center mx-auto mt-5">
			<p>Thank you for your message, we appreciate all feedback and will respond as soon as we can.</p>
			<p><a class="btn btn-danger" href="index">Go to Home page</a> or <a class="btn btn-danger" href="support">Return to Support page</a></p>
		</div>
	</div>
</div>

<!-- End of page content -->
<?php include("templating/footer.php"); ?>
<?php include("templating/scripts.php"); ?>
</body>
</html>