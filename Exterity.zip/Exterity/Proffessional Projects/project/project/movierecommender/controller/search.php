<?php
    header('Location: ../view/show?t=' . urlencode($_GET['search'])); //Search the TMDB to find the Show
    exit;
?>