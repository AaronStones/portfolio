<?php
    header('Content-Type', 'application/json');
    include_once("../model/api_user.php");

    session_start();
    if (!isset($_SESSION['user']))
    {
        exit; // User isn't logged in
    }
    $user = $_SESSION['user']; // For shorter access later

    $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';

    if (!$_SERVER["REQUEST_METHOD"] == "POST" || !isset($_POST['newEmail']) || !isset($_POST['password']))
    {
        // Recieved incorrect data and/or request method
        $error_message = 'Something went wrong.<br />';
    }
    else
    {
        if (checkEmail($_POST['newEmail']))
            $error_message .= 'That Email Address is already in use.<br />';
        if (!preg_match($email_exp, $_POST['newEmail']))
            $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
        if (!confirmPassword($user->id, $_POST['password']))
            $error_message .= 'The Password you entered is incorrect.<br />';
    }

    if(strlen($error_message) > 0) // Failure
    {
        echo json_encode(array('success' => false, 'message' => $error_message));
    }
    else // Success
    {
        if (changeEmail($user->id, $_POST['newEmail']))
        {
            // Relog so details are not out of date
            $_SESSION['user'] = json_decode(getUser($_POST['newEmail'], $_POST['password']));
            echo json_encode(array('success' => true, 'message' => 'Email Successfully changed'));
        }
        else
            echo json_encode(array('success' => false, 'message' => 'Something went wrong'));
    }
?>