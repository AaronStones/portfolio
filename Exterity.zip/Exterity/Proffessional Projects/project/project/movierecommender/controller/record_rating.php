<?php
    header('Content-Type', 'application/json');
    include_once("../model/api_ratings.php");

    session_start();
    if (!isset($_SESSION['user']))
    {
        exit; // User isn't logged in
    }
    $user = $_SESSION['user'];

    recordRating($user->id, $_POST['movie_id'], $_POST['rating'])
?>