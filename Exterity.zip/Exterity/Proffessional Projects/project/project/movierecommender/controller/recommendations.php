<?php
session_start();

include_once("../model/api_ratings.php");
include_once("../model/api_tmdb.php");

$recommendations = getRecommendations($_SESSION['user']->id);

foreach($recommendations as $recommendation):?>
    <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12">
    <div id="<?=$recommendation[0]?>" class="card">
    <img class="card-img-top" alt="Poster image for <?=$recommendation[2]?>" src="<?php
        $show = json_decode(findShow($recommendation[2]));
        if ($show->success)
        {
            echo $show->poster_path;
        }
        else
        {
            echo 'images/poster_not_available.jpg';
        }
    ?>" alt="Card" image style="width:100%" height="300" width="500">
    <div class="card-body">
    <h4 class="card-title"><?=$recommendation[2]?></h4>
    <div class="w-100 p-1 text-center">
            <i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$recommendation[0]?>, 1)"> </i>
            <i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$recommendation[0]?>, 2)"> </i>
            <i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$recommendation[0]?>, 3)"> </i>
            <i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$recommendation[0]?>, 4)"> </i>
            <i class="fa fa-star expected-checked" onclick="ratingClicked(<?=$recommendation[0]?>, 5)"> </i>
    </div>
    </div>
    </div>
    </div>
<?php endforeach;?>