<?php
    header('Content-Type', 'application/json');
    include_once("../model/api_user.php");

    session_start();
    if (!isset($_SESSION['user']))
    {
        exit; // User isn't logged in
    }
    $user = $_SESSION['user']; // For shorter access later

    $error_message = "";

    if (!$_SERVER["REQUEST_METHOD"] == "POST" || !isset($_POST['newPassword']) || !isset($_POST['newConfirm']) || !isset($_POST['password']))
    {
        // Recieved incorrect data and/or request method
        $error_message = 'Something went wrong.<br />';
    }
    else
    {
        if (!confirmPassword($user->id, $_POST['password']))
            $error_message .= 'The Password you entered is incorrect.<br />';
        if (strlen($_POST['newPassword']) <= 8)
            $error_message .= 'You have entered too weak a password, please ensure the new password is 8 characters and contains at least one letter and number. <br />';
        if (!preg_match("#[0-9]+#", $_POST['newPassword']))
            $error_message .= 'New password must include at least one number. <br />';
        if (!preg_match("#[a-zA-Z]+#", $_POST['newPassword']))
            $error_message .= 'New password must include at least one letter. <br />'; 
        if ($_POST['newPassword'] != $_POST['newConfirm'])
            $error_message .= 'New password must match the Repeated Password. <br />';
    }

    if(strlen($error_message) > 0) // Failure
    {
        echo json_encode(array('success' => false, 'message' => $error_message));
    }
    else // Success
    {
        if (changePassword($user->id, $_POST['newPassword']))
            echo json_encode(array('success' => true, 'message' => 'Password Successfully changed'));
        else
            echo json_encode(array('success' => false, 'message' => 'Something went wrong'));
    }
?>