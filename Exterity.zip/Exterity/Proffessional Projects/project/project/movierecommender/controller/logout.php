<?php
	// Logout of session
	session_start();
	$_SESSION = array();
	setcookie(session_name(), '', time() - 9999999, '/');
    session_destroy();
    
    header('Location: ../view/index');
?>