<?php
    header('Content-Type', 'application/json');
    include_once("../model/api_user.php");

    session_start();
    if (!isset($_SESSION['user']))
    {
        exit; // User isn't logged in
    }
    $user = $_SESSION['user']; // For shorter access later

    $error_message = "";

    if (!$_SERVER["REQUEST_METHOD"] == "POST" || !isset($_POST['password']))
    {
        // Recieved incorrect data and/or request method
        $error_message = 'Something went wrong.<br />';
    }
    else
    {
        if (!confirmPassword($user->id, $_POST['password']))
            $error_message .= 'The Password you entered is incorrect.<br />';
    }

    if(strlen($error_message) > 0) // Failure
    {
        echo json_encode(array('success' => false, 'message' => $error_message));
    }
    else // Success
    {
        if (deleteUser($user->id))
        {
            // End session as user no longer exists
            session_start();
            $_SESSION = array();
            setcookie(session_name(), '', time() - 9999999, '/');
            session_destroy();

            echo json_encode(array('success' => true, 'message' => 'Account successfully deleted'));
        }
        else
            echo json_encode(array('success' => false, 'message' => 'Something went wrong'));
    }
?>