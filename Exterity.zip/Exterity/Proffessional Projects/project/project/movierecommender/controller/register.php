<?php
    header('Content-Type', 'application/json');
    include_once("../model/api_user.php");

    $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';

    if (!$_SERVER["REQUEST_METHOD"] == "POST" || !isset($_POST['email']) || !isset($_POST['password']) || !isset($_POST['confirm']))
    {
        // Recieved incorrect data and/or request method
        $error_message = 'Something went wrong.<br />';
    }
    else //Check User input
    {
        if (checkEmail($_POST['email']))
            $error_message .= 'That Email Address is already in use.<br />';
        if (!preg_match($email_exp, $_POST['email']))
            $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
        if (strlen($_POST['password']) < 8)
            $error_message .= 'You have entered too weak a password, please ensure the password is 8 characters and contains at least one letter and number. <br />';
        if (!preg_match("#[0-9]+#", $_POST['password']))
            $error_message .= 'Password must include at least one number. <br />';
        if (!preg_match("#[a-zA-Z]+#", $_POST['password']))
            $error_message .= 'Password must include at least one letter. <br />'; 
        if ($_POST['password'] != $_POST['confirm'])
            $error_message .= 'Password must match the Repeated Password. <br />';
    }

    if(strlen($error_message) > 0) // Failure
    {
        echo json_encode(array('success' => false, 'message' => $error_message));
    }
    else // Success
    {
        include("../test/getUser.php") ;
        registerUser($_POST['email'], $_POST['password']);
        echo json_encode(array('success' => true, 'message' => 'Registration Successful. Redirecting...'));
    }
?>