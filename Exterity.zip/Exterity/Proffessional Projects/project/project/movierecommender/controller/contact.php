<?php
    $from = $_POST["email"];
    $message = $_POST["message"];
    $subject = $_POST["subject"];

    // Validation
    if (!preg_match('/^(?=.{5,80}$)[\S]+@[\S]+\.[\S]+$/', $from)) // Validate email
    {
        header("location: ../view/error");
        exit;
    }

    if (!preg_match('/^.{1,1200}$/', $message)) // Validate message
    {
        header("location: ../view/error");
        exit;
    }

    // Send email to movie recommender address
    $to = "1803259@uad.ac.uk";
    $fullMessage = wordwrap("Movie Recommender - From: $from\n\n$message");
    mail($to, 'Movie Recommender - ' . $subject, $fullMessage);


    // Send email to sender to confirm that the message was sent
    $fullMessage = wordwrap("You sent the following message to the Movie Recommender team under the subject \"$subject\":\n\n$message");
    mail($from, 'Thank you for your feedback', $fullMessage);

    header("location: ../view/message_sent");
?>