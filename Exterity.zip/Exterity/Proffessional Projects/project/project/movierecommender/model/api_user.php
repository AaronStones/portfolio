<?php
	include_once('../../databaseconnection.php'); // Include connection 
	
	// Registers a new user
	function registerUser($email, $password)
	{
		global $pdo;
		
		$date_joined = date('Y-m-d');
		$hash = password_hash($password, PASSWORD_DEFAULT);
		
		$statement = $pdo->prepare('INSERT INTO MR_User (email, hash) VALUES (:email, :hash)');
		$statement->bindParam(':email', $email);
		$statement->bindParam(':hash', $hash);
		$statement->execute();
    }
    
	// Check whether an email is in use
	function checkEmail($email)
	{
        global $pdo;
        
		$statement = $pdo->prepare('SELECT EXISTS(SELECT 0 FROM MR_User WHERE email = :email) AS \'exists\'');
		$statement->bindParam(':email', $email);
        $statement->execute();
        
		return $statement->fetch()['exists'] == 1;
	}
	
	// Check a users login details and returns that user if they are correct (return null otherwise)
	function getUser($email, $password)
	{
		global $pdo;
		
		$statement = $pdo->prepare('SELECT id, email, admin, hash FROM MR_User WHERE email = :email');
		$statement->bindParam(':email', $email);
		$statement->execute();
		
		if ($statement->rowCount() == 0)
		{
			return null; // Email does not exist
		}
		
		$row = $statement->fetch();
		
		if (!password_verify($password, $row['hash']))
		{
			return null; // Password does not match hash
		}

		// Everything in order, return user data as JSON
		return json_encode(array(
			'id' => $row['id'],
			'email' => $row['email'],
			'admin' => $row['admin']));
	}

	// Confirm that the given password is correct for the account with the given ID
	function confirmPassword($id, $password)
	{
		global $pdo;
		
		$statement = $pdo->prepare('SELECT hash FROM MR_User WHERE id = :id');
		$statement->bindParam(':id', $id);
		$statement->execute();
		
		if ($statement->rowCount() == 0)
		{
			return false; // ID does not exist
		}
		
		$row = $statement->fetch();
		
		return password_verify($password, $row['hash']);
	}

	// Change the email associated with a given account, return true if the change was successful
	function changeEmail($id, $newEmail)
	{
		global $pdo;
		
		$statement = $pdo->prepare('UPDATE MR_User SET email = :newEmail WHERE id = :id');
		$statement->bindParam(':id', $id);
		$statement->bindParam(':newEmail', $newEmail);
		$statement->execute();

		return $statement->rowCount() > 0;
	}

	// Change the password associated with a given account, return true if the change was successful
	function changePassword($id, $newPassword)
	{
		global $pdo;
		
		$hash = password_hash($newPassword, PASSWORD_DEFAULT);

		$statement = $pdo->prepare('UPDATE MR_User SET hash = :hash WHERE id = :id');
		$statement->bindParam(':id', $id);
		$statement->bindParam(':hash', $hash);
		$statement->execute();

		return $statement->rowCount() > 0;
	}

	// Permanently delete the specified account, returns true if the deletion was successful
	function deleteUser($id)
	{
		global $pdo;
		
		$statement = $pdo->prepare('DELETE FROM MR_User WHERE id = :id');
		$statement->bindParam(':id', $id);
		$statement->execute();

		$statement_ratings = $pdo->prepare('DELETE FROM MR_Rating WHERE user_id = :id');
		$statement_ratings->bindParam(':id', $id);
		$statement_ratings->execute();

		return $statement->rowCount() > 0;
	}
?>