<?php
    include_once('../../databaseconnection.php'); // Include connection 
    
	// Returns ID of movie with given title, or null if no movie with that title can be found
	function getMovieID($title)
	{
		global $pdo;
		
		$statement = $pdo->prepare('SELECT id FROM MR_Movie WHERE title = :title');
		$statement->bindParam(':title', $title);
		$statement->execute();
		
		if ($statement->rowCount() == 0)
		{
			return null; // Movie does not exist in our (small) dataset
        }
        else
        {
            return $statement->fetch()['id']; // Everything in order, return movie ID
        }
	}

	function firstMovies()
	{
		
		global $pdo;
		
		$statement = $pdo->prepare('SELECT * FROM MR_Reg');
		$statement->execute();
		while ($row = $statement->fetch(PDO::FETCH_ASSOC)) 
			{
				$rows[] = $row;
			}
		$initial = json_encode($rows);
		return ($initial);
	}
?>