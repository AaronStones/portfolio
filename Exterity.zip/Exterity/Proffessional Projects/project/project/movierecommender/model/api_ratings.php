<?php
    include_once('../../databaseconnection.php'); // Include connection

    // Save a single ratings record to the database
	function recordRating($user_id, $movie_id, $rating)
	{
		global $pdo;
		
		$statement = $pdo->prepare('REPLACE INTO MR_Rating (user_id, movie_id, rating) VALUES (:user_id, :movie_id, :rating)');
		$statement->bindParam(':user_id', $user_id);
        $statement->bindParam(':movie_id', $movie_id);
        $statement->bindParam(':rating', $rating);
		$statement->execute();
	}
	
	// Get the number of ratings a user has made (to detect whether they still need to go through the registration process)
	function getRatingCount($user_id)
	{
		global $pdo;
		
		$statement = $pdo->prepare('SELECT COUNT(*) AS \'count\' FROM MR_Rating WHERE user_id = :user_id');
		$statement->bindParam(':user_id', $user_id);
		$statement->execute();
		
		return $statement->fetch()['count'];
	}

	// Get the rating of a user and movie
	function getRating($user_id, $movie_id)
	{
		global $pdo;
		
		$statement = $pdo->prepare('SELECT rating FROM MR_Rating WHERE user_id = :user_id AND movie_id = :movie_id');
		$statement->bindParam(':user_id', $user_id);
        $statement->bindParam(':movie_id', $movie_id);
		$statement->execute();

		return $statement->fetch()['rating'];
	}
	
	// Get movie recommendations for a user
	function getRecommendations($user_id)
	{
		global $pdo;

		$statement = $pdo->prepare('SELECT movie_id, rating FROM MR_Rating WHERE user_id = :user_id');
		$statement->bindParam(':user_id', $user_id);
		if ($statement->execute())
		{
			// Compile users ratings into string
			$ratings = '{';
			while ($row = $statement->fetch(PDO::FETCH_ASSOC)) 
			{
				$ratings = $ratings . $row['movie_id'] . ': ' . $row['rating'] . ',';
			}
			$ratings = substr($ratings, 0, -1) . '}';

			// Get recommendations from API
			$url = 'http://206.189.116.171';
			$data = array('user_ratings' => $ratings);
			$options = array(
				'http' => array(
					'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
					'method'  => 'POST',
					'content' => http_build_query($data)
				)
			);
			$context  = stream_context_create($options);
			$result = file_get_contents($url, false, $context);

			return json_decode($result);
		}
		else
		{
			return null;
		}
    }
?>