<?php
    include("../../api_key_tmdb.php");

    // Find a tv show or movie using the given title as a search string
    function findShow($title)
    {
        global $api_key_tmdb;

        // Use TMDb multi-search which searches for movies, tv shows, and people
        $url = 'https://api.themoviedb.org/3/search/multi?api_key=' . $api_key_tmdb . '&language=en-GB&query=' . urlencode($title) . '&page=1&include_adult=false';
        $response = file_get_contents($url);
        $raw = json_decode($response);

        if ((isset($raw->success) && $raw->success == false) || $raw->total_results == 0)
        {
            // Either something went wrong or no results were found at all
            return json_encode(array('success' => false));
        }
        else
        {
            // Iterate through the retrieved page of results until a result is found that is not a person
            foreach ($raw->results as $result)
            {
                if ($result->media_type != 'person')
                {
                    // Found a result that is not a person, this result must either be a movie or a tv show
                    return $result->media_type == 'movie' ? getMovieByID($result->id) : getTVShowByID($result->id);
                }
            }
            // All of the results were people and so no movie was found
            return json_encode(array('success' => false));
        }
    }

    // Get details for a show using a movie ID
    function getMovieByID($id)
    {
        global $api_key_tmdb;

        // Use TMDb API to retrieve details about the movie
        $url = 'https://api.themoviedb.org/3/movie/' . $id . '?api_key=' . $api_key_tmdb . '&language=en-GB';
        $response = file_get_contents($url);
        $details = json_decode($response);

        // Build an array containing the names of the genres
        $genres = array();
        foreach($details->genres as $genre)
        {
            array_push($genres, $genre->name);
        }

        // Build an array containing the names of the producers
        $producedBy = array();
        foreach($details->production_companies as $producer)
        {
            array_push($producedBy, $producer->name);
        }

        $show = array(
            'success' => true,
            'title' => $details->title,
            'year' => substr($details->release_date, 0, 4),
            'overview' => $details->overview,
            'poster_path' => 'https://image.tmdb.org/t/p/w185' . $details->poster_path,
            'genres' => $genres,
            'produced_by' => $producedBy);
        
        return json_encode($show);
    }

    // Get details for a show using a TV show ID
    function getTVShowByID($id)
    {
        global $api_key_tmdb;

        // Use TMDb API to retrieve details about the TV show
        $url = 'https://api.themoviedb.org/3/tv/' . $id . '?api_key=' . $api_key_tmdb . '&language=en-GB';
        $response = file_get_contents($url);
        $details = json_decode($response);

        // Build an array containing the names of the genres
        $genres = array();
        foreach($details->genres as $genre)
        {
            array_push($genres, $genre->name);
        }

        // Build an array containing the names of the producers
        $producedBy = array();
        foreach($details->production_companies as $producer)
        {
            array_push($producedBy, $producer->name);
        }

        $show = array(
            'success' => true,
            'title' => $details->name,
            'year' => substr($details->first_air_date, 0, 4),
            'overview' => $details->overview,
            'poster_path' => 'https://image.tmdb.org/t/p/w342' . $details->poster_path,
            'genres' => $genres,
            'produced_by' => $producedBy);
        
        return json_encode($show);
    }
?>
