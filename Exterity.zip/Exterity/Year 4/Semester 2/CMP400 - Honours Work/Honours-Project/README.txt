Link to Web App - https://mayar.abertay.ac.uk/~1600964/Honours-Project/Android/APIs/View/index

for system diagram use - https://www.draw.io/

Gantt Chart - created using project Libre (free and open source)

Email/password for Mobile App - stonesclan090@gmail.com/password

email/password for web app - g.lund@gmail.com/password
