<?php
ini_set("display_errors", 1);
error_reporting(E_ALL);

include("../Model/Advice.php");

function getAdvice($email){
    $check = null;

    return adviceDatabase($email);
}

?>