<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="https://mayar.abertay.ac.uk/~1600964/Honours-Project/Android/APIs/View/index">Elderly Helper</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Help<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="https://mayar.abertay.ac.uk/~1600964/Honours-Project/Android/APIs/View/account">Account</a></li>
          <li><a href="https://mayar.abertay.ac.uk/~1600964/Honours-Project/Android/APIs/View/aboutus">About Us</a></li>
          <li><a href="https://mayar.abertay.ac.uk/~1600964/Honours-Project/Android/APIs/View/support">FAQs</a></li>
          <li><a href="https://mayar.abertay.ac.uk/~1600964/Honours-Project/Android/APIs/View/support">Contact us</a></li>

        </ul>
      </li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="https://mayar.abertay.ac.uk/~1600964/Honours-Project/Android/APIs/View/signup"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="https://mayar.abertay.ac.uk/~1600964/Honours-Project/Android/APIs/View/login"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>