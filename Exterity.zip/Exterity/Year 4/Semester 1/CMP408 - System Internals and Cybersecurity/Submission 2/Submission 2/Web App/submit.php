<?php
//Aaron Stones
//External File Try
//File does not affect outcome and was only attempted
//1600964



function setVariables(){ //tried to get this file operational but could not 
    $pinno = $_POST["pinno"];
    $option = $_POST["taskOption"];
    performAction($pinno, $option);
}

function performAction($pinno, $option){
    echo shell_exec('sudo /home/pi/Submission2/Driver_Test_App/a.out writepin ' . $pinno . " " . $option);

}

function toggleAction($pinno, $option, $frequency, $loop){
    echo shell_exec('sudo /home/pi/Submission2/Driver_Test_App/a.out togglepin ' . $pinno . " " . $option . " " . $loop . " " . $frequency);

}

function readAction($pinno, $option){
    echo shell_exec('sudo /home/pi/Submission2/Driver_Test_App/a.out readpin ' . $pinno . " " . $option);

}


?>
