<!-- Aaron Stones - 1600964
CMP408
RPi GPIO submission 2 HTML/ php document
29/10/19-->
 



<h1>Write</h1>
<form method="post"> <!-- Write Form -->
	<input type="hidden" name="Write" value="1"> <!-- Setup unique Write hidden field to identify this form -->
	GPIO Pin Number:    <input type="text" name="pinno"><br>
	GPIO Pin Value: 
	  <select name="taskOption">
	  <option value="1">on</option><br>
	  <option value="0">off</option><br>
	  </select>
	  <input type="submit" name="btnSendForm" value="Submit">
</form>
<h1>Read</h1> <!-- Read Form -->
<form method="post">
        <input type="hidden" name="Read" value="1"> <!-- Setup unique Read hidden field to identify this form -->
        GPIO Pin Number:    <input type="text" name="pinno"><br>
        <input type="submit" name="btnSendForm" value="Submit">
</form>
<h1>Toggle</h1> <!-- Toggle Form gets no hidden field as it has fields unique to itself-->
<form method="post">
        GPIO Pin Number:    <input type="text" name="pinno"><br>
        GPIO Pin Value: 
          <select name="taskOption">
          <option value="1">on</option><br>
          <option value="0">off</option><br>
          </select>
        Times:    <input type="text" name="Loop"><br>

        Frequency:    <input type="text" name="frequency"><br>

          <input type="submit" name="btnSendForm" value="Submit">
</form>

<?php
#include("submit.php");
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["frequency"])){ //check if the toggle feature has been activated
        echo "<h2>Toggling</h2>";
	echo shell_exec('sudo /home/pi/Submission2/Driver_Test_App/a.out togglepin ' . $_POST["pinno"] . " " . $_POST["taskOption"] . " " . $_POST["Loop"] . " " . $_POST["frequency"]); //execute toggle command
	//toggleAction($_POST["pinno"], $_POST["taskOption"], $_POST["frequency"], $_POST["Loop"]);
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Write"])){ //check if the Write feature has been activated
        echo "<h1>Writing</h2>";
	echo shell_exec('sudo /home/pi/Submission2/Driver_Test_App/a.out writepin ' . $_POST["pinno"] . " " . $_POST["taskOption"]); //execute write function
	//setVariables($_POST["pinno"], $_POST["taskOption"]);
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["Read"])){ //check if the Read feature has been activated
	echo "<h2>Reading</h2>";
	echo shell_exec('sudo /home/pi/Submission2/Driver_Test_App/a.out readpin ' . $_POST["pinno"]); //execute read function 
        //readAction($_POST["pinno"], $_POST["taskOption"]);
}


?>
