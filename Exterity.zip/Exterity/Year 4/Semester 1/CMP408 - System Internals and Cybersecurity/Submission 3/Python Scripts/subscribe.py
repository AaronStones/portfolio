#Name: Aaron Stones
#Student Number: 1600964
#Assesment 3
#CMP408

import paho.mqtt.client as mqtt #import the client1
import time
def on_message(client, userdata, message):
    print("\nmessage received: ", str(message.payload.decode("utf-8")))
    print("message topic: ", message.topic)
    
def on_connect(client, userData, flags, rc):
    if rc == 0:
        print("connected successfully\n")
    else:
        print("connection failed Returned Code=", rc) #connection failed 
        exit(1)
    
broker_address="ec2-35-174-136-129.compute-1.amazonaws.com"

userName = input("Please enter your username: ") #get user details
pWord = input("Please enter your password: ")

print("\ncreating new instance")
client = mqtt.Client("Subscribe") #create new instance

client.on_connect = on_connect #attach function to callback
client.on_message=on_message 
client.username_pw_set(username=userName, password=pWord)

print("connecting to broker")
client.connect(broker_address, port=1883) #connect to broker
client.loop_start() #start the loop

topic = input("Please select a subscription topic: ")

print("Subscribing to topic", topic)
client.subscribe(topic)

time.sleep(10) # wait
client.loop_stop() #stop the loop