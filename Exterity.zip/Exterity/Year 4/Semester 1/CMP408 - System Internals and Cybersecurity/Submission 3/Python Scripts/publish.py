#Name: Aaron Stones
#Student Number: 1600964
#Assesment 3
#CMP408

import paho.mqtt.client as mqtt #import mqtt

userName = input("Please enter your username: ") #get user details
pWord = input("Please enter your password: ")
userCheck = False

broker_address="ec2-35-174-136-129.compute-1.amazonaws.com" #set the aws hostname

print("creating new instance")
client = mqtt.Client("Assessnent 3") #create new instance

print("connecting to broker")
client.username_pw_set(username=userName, password=pWord)
client.connect(broker_address, port=1883) #connect to broker

client.loop_start() #start the loop
subject = input("please enter the topic you would like: ") #get the user to enter the topic 

while userCheck == False:
    message = input("Please enter your message: ")
    
    client.publish(subject, message) #publish this message and topic
    
    userChoice = input("Would you like to post another?")
    if userChoice == "no":
        userCheck = True #user has decided not to proceed with writing publications so quit


client.loop_stop() #stop the loop and close the session