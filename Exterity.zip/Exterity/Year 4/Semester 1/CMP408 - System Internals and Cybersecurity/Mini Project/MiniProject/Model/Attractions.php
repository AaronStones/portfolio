<?php

//include("../Model/conn.php");
    
function getLocId($location){

    $conn = openConn();
    $result = $conn->query("SELECT id FROM Locations WHERE Loc='$location'");
    $results = $result->fetch_all();
    CloseConn($conn);

    return $results;
    
}

function getAttraction($val){

    $conn = openConn();
    $result = $conn->query("SELECT * FROM Attractions WHERE Location='$val'");
    $results = $result->fetch_all();
    CloseConn($conn);

    return $results;
    
}
?>