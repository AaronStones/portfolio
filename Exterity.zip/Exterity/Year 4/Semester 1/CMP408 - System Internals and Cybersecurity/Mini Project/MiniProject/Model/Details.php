<?php

include("../Model/conn.php");
    
function getDetails($id){

    $conn = openConn();
    $result = $conn->query("SELECT jsonData FROM Details WHERE attractionId='$id'");
    $results = $result->fetch_all();
    CloseConn($conn);

    return $results;
    
}
?>