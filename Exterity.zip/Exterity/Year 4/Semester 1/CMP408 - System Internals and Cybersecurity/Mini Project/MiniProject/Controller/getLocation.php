<?php

ini_set("display_errors", 1);
error_reporting(E_ALL);

function getData($location){
    include("../Model/Attractions.php");
    include("../Model/Details.php");
    $val = getLocId($location);
    $Attraction = getAttraction($val[0][0]);

    for ($i =0; $i < sizeof($Attraction); $i++){
        echo "<h4>" . $Attraction[$i][2] . "</h4><br/>";
        $Details = getDetails($Attraction[$i][0]);
        $Details = json_decode($Details[0][0]);
        echo "<img src='" . $Details->Image . "' alt='" . $Attraction[$i][2] . "'><br/>";
        echo $Details->about . "<br/>";
        echo "<b>This was built in " . $Details->date . "</b><br/>";
    }

}
?>