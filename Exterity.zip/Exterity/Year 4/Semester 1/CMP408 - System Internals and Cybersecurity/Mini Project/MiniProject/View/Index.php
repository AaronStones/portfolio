
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <?php include("templates/header.php"); ?>
</head>
    <body>

            <div class="header">
                <a href="Index.php"><h1>Mini Project - CMP408</h1></a>
                <h3>Aaron Stones | BSc Computing | Abertay University</h3>
            </div>
            <div class="form">
                <h3>Please select your location</h3>
                <form method="post" style="float">
                    <select name="Location" id="Location" style="text-align: center; text-align-last: center; width: 100%;">
                        <option style="text-align: left;" value = "Perth">Perth</option>
                        <option style="text-align: left;" value = "Dundee">Dundee</option>
                        <option style="text-align: left;" value = "Stirling">Stirling</option>
                    </select>
                    <input type="submit" style="width: 100%;">
                </form>
            </div>
        <div class="content">
            <?php 
                if ($_SERVER["REQUEST_METHOD"] == "POST") { //get user data
                    include("../Controller/getLocation.php");
                    getData($_POST['Location']);
                }
    
            ?>
        </div>

        <?php include("templates/footer.php"); ?>
    </body>
</html>