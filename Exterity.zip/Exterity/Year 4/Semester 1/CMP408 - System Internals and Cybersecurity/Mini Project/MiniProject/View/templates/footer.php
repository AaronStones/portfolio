<link rel="stylesheet" type="text/css" href="css/footer.css">
<div class="search-text"> 
   <div class="container">
     <div class="row text-center">
     
       <div class="form">
           <h4>SIGN UP TO OUR NEWSLETTER</h4>
            <form id="search-form" class="form-search form-horizontal">
                <input type="text" class="input-search" placeholder="Email Address">
                <button type="submit" class="btn-search">SUBMIT</button>
            </form>
        </div>
    
      </div>         
   </div>     
</div>

<footer>
 <div class="container">
   <div class="row">
   
            <div class="col-md-4 col-sm-6 col-xs-12">
              <span class="logo">Mini Project</span>
              <img src="https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Fwww.freepnglogos.com%2Fuploads%2Fs-letter-logo-png-15.png">
            </div>
            
            <div class="col-md-4 col-sm-6 col-xs-12">
                <ul class="menu">
                     <span>Menu</span>    
                     <li>
                        <a href="#">Home</a>
                      </li>
                           
                      <li>
                         <a href="#">About</a>
                      </li>
                           
                      <li>
                        <a href="#">Contact Us</a>
                      </li>
                           
                      <li>
                         <a href="#">FAQs </a>
                      </li>
                 </ul>
            </div>
       
            <div class="col-md-4 col-sm-6 col-xs-12">
              <ul class="address">
                <span>Contact</span>       
                   <li>
                       <i class="fa fa-phone" aria-hidden="true"></i> <a href="#">Phone</a>
                   </li>
                   <li>
                       <i class="fa fa-map-marker" aria-hidden="true"></i> <a href="#">Address</a>
                   </li> 
                   <li>
                      <i class="fa fa-envelope" aria-hidden="true"></i> <a href="#">Email</a>
                   </li> 
               </ul>
           </div>
       
       
       </div> 
    </div>
</footer>