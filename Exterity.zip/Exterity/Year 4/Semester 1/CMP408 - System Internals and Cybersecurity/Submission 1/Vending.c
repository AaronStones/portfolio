#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
 

 	void addMachine();
	void showMachines();
	void indexSearch();
	void deleteMachine();
	void updateStatus();
	void exitProgram();
	void showOptions(); //initialise functions

void main(){

	showOptions(); //show options to user
	

}

void showOptions(){
	
    printf("******************************************************\n");
    printf("*vending Machine Control Console\t\t     *\n");
    printf("*\t\t\t Submitted by: Aaron Stones  *\n");
    printf("*\t\t\t Student ID: 1600964         *\n");
    printf("*\t\t\t Abertay University          *\n");
    printf("******************************************************\n");
    printf("1. Add Machine\n");
    printf("2. Show All Machines\n");
    printf("3. Search By Index\n");
    printf("4. Delete Machine\n");
    printf("5. Update Status\n");
    printf("6. Exit\n");
    printf("******************************************************\n");
	int userChoice;
	error:
	printf("Enter your Choice : "); //direct the user based on their choice, invalid choices means this process is repeated
	scanf("%d",&userChoice);
	switch (userChoice){
		case 1: addMachine();
			break;
		case 2: showMachines();
			break;
		case 3: indexSearch();
			break;
		case 4: deleteMachine();
			break;
		case 5: updateStatus();
			break;
		case 6: exitProgram();
			break;
		default: 
			goto error; //defualt for error get user to start again


	}

}

void showMachines(){
	printf("Index\t Name\t Location Pin Status\n\n"); //setup table
	char NameArr[20][256];
	char comma = ',';
    DIR *dir;
    int i=0,k;
	int count = 1;
	char counter[5] ="";
    struct dirent *ent;
    dir = opendir ("database"); //declare the directory
    if (dir != NULL) 
    {
    	while ((ent = readdir (dir)) != NULL) 
        	{
        		strcpy(NameArr[i],ent->d_name); //copy the name to the array
        		i++;
			}
    	closedir (dir); //close directory
    } 
    else
    {
    	printf("%s\n", "unknown error please try again.");
		showOptions();
    }

	for (k=2;(k<(i+1)) && (k<20);k++){ //start loop from 2 because there are hidden files
		char str[20];
		char fileName[20] = "";
		strcat(fileName, "database/");
		strcat(fileName, NameArr[k]); //create the filename
		FILE * fPtr;

		char ch;
		fPtr = fopen(fileName, "r");

		if(fPtr == NULL)
		{
		
		}
		printf("%s\t", NameArr[k]); //print the filename
		do 
		{
			
			ch = fgetc(fPtr);
			if(comma == ch){
				ch = ' '; //remove the commas
				printf("%s", "\t");
			}
			putchar(ch);

		} while(ch != EOF); 

		fclose(fPtr);
		printf("\n");

	}
		showOptions();

	

}

void addMachine(){
	char data[1000] = "";
	char pin[20];
	char name[20];
	char location[20];
	char status[20];

	char intStore[20] = "";
	char filename[20] = "";
	printf("Please enter the machine's name\n"); //get all of the data from the user about the new machine
	scanf("%s", name); 
	printf("Please specify the machine's location\n");
	scanf("%s", location);
	printf("Please enter the machine's status (1: for Online, 0: for Offline)\n");
	scanf("%s", status); 
	printf("Please enter the machine's pin\n");
	scanf("%s", pin); 
	strcat(data, name);
	strcat(data, ",");
	strcat(data, location);
	strcat(data, ",");
	strcat(data, status);
	strcat(data, ",");
	strcat(data, pin); //put the data into a desirable format

	int createFile();
	int number = createFile(); //create a new unique file
	strcat(filename, "database/");
	sprintf(intStore, "%d", number);
	strcat(filename, intStore);
	strcat(filename, ".txt"); //create the filepath for the new unique file
	FILE * fp;
	int i =0;
	fp = fopen (filename,"w");
	
		fprintf (fp, data, 0); //put the data into line 0 of the file
	
	fclose (fp);
			showOptions();

}

int createFile(){
	char NameArr[20][256];
    DIR *dir;
    int i=0,k;
	int count = 1;
	char counter[5] ="";
    struct dirent *ent; //create a struct for the directory
    dir = opendir ("database");
    if (dir != NULL) 
    {
    	while ((ent = readdir (dir)) != NULL) 
        	{
        		strcpy(NameArr[i],ent->d_name); //save the filenames to an array 
        		i++;
        	}
    	closedir (dir);
    } 
    else
    {
    	/* could not open directory */
    	perror ("");
    }
    for (k=2;(k<(i+1)) && (k<20);k++){ 
		char str[20];
		char new[20] = "";
		char filename[20]="";
		sprintf(str, "%d", count);
		strcat(new, str);
		strcat(new, ".txt");
		if (strcmp(new, NameArr[k])){
			strcat(filename, "database/");
			strcat(filename, new);
			FILE *file_pointer; 
	
			file_pointer = fopen(filename, "w"); //open file for write
		
			// Write to the file
			fprintf(file_pointer, "This will write to a file.");
			
			// Close the file
			fclose(file_pointer); 
			printf("%s\n", new);
		}
		else{
			count++;
		}
	}
    return count; //return the file index
}

void deleteMachine(){
	char file[80] = "";
	char userChoice[20];
	printf("Enter a machine's index to delete it : ");
	scanf("%s", userChoice); 
	strcat(file, "database/");
	strcat(file, userChoice);
	strcat(file, ".txt");

	if (remove(file) == 0) { //delete the file selected by the user
    	printf("Deleted successfully\n"); 
	}
   	else{
		printf("Vending machine doesn't exist please try again\n");  //send back to start 
		showOptions();
	}
	showOptions();

}

void updateStatus(){
	char file[80] = "";
	char c[1000];
	char userChoice[20];
	int userAnswer;
	printf("Enter a machine's index : ");
	scanf("%s", userChoice); 
	strcat(file, "database/");
	strcat(file, userChoice);
	strcat(file, ".txt");

    FILE *fptr;
    if ((fptr = fopen(file, "r")) == NULL) //try and open the file the user has selected
    {
        printf("Vending machine does not exist!\n");
		showOptions();
    }
    fscanf(fptr,"%[^\"]", c);
    printf("%s\n", c);
	if (c[(strlen(c)-1)] == '0'){
		printf("%s\n", "this machine is offline, would you like to turn it on? (enter 1 for yes)"); //the machine is offline ask to turn it on
		scanf("%d", &userAnswer);
		if (userAnswer == 1){

			c[(strlen(c)-1)] = '1';
			FILE * fp;
			fp = fopen (file,"w");
			
			fprintf (fp, c, 0);//change last character of string to 1
			
			fclose (fp);
			

		}
		else {
			showOptions();
		}
	}
	else{
		printf("%s\n", "this machine is online, would you like to turn it off? (enter 1 for yes)"); //machine is online ask to turn it off
		scanf("%d", &userAnswer);
		if (userAnswer == 1){
			
			c[(strlen(c)-1)] = '0'; //change last character of string to 0 
			FILE * fp;
			fp = fopen (file,"w");
			
			fprintf (fp, c, 0);
			
			fclose (fp);
		}
		else {
			showOptions();
		}
	}
		fclose(fptr);
	showOptions();


}

void exitProgram(){
	printf("Goodbye!\n");
	exit(0); //exit program
}

void indexSearch(){
	char file[80] = "";
	char c[1000];
	char data[1000];
	char userChoice[20];

	printf("Enter a machine's index : ");
	scanf("%s", userChoice); 
	strcat(file, "database/");
	strcat(file, userChoice);
	strcat(file, ".txt");

    FILE *fptr;
    if ((fptr = fopen(file, "r")) == NULL) //open the file for read
    {
        printf("file does not exist please try again\n"); //if the file can't be opened error present and start again
		showOptions();
    }
    fscanf(fptr,"%[^\"]", c);
    fclose(fptr);
	printf("Index\t Name\t Location Pin Status\n\n"); //display that machines details
	printf("%s\n", c);
	showOptions();

}
